
local before=api('observe_scene',{}); local s=before.data
assert(before.valid and s.actor.navigationProfileSupported)
local bag=api('inspect_inventory',{mode='hotbar'}); local material=nil
for _,i in ipairs(bag.data.inventory) do if i.use.createTile==30 and i.stack>0 then material=i; break end end
assert(material and #s.placementCandidates.items>0)
api('select_hotbar_slot',{slot=material.hotbarKey})
local site=s.placementCandidates.items[1]
local placed=api('place_tile',site.target)
assert(placed.valid and placed.completed and placed.evidence.consumedCount==1)
local check=api('inspect_tile',site.target);assert(check.data.cell.hasTile and check.data.cell.tileType==30)
local goal=nil
for _,r in ipairs(s.landingRegions.items) do
  if r.feetDeltaY<=-64 and r.target.minPlayerLeftX>s.actor.boundsWorldPixels.x+64 then goal=r;break end
end
assert(goal)
local up=api('navigate_to_landing_region',goal.target)
assert(up.valid and up.completed and up.evidence.settled)
local fresh=api('observe_scene',{}); local back=nil
for _,r in ipairs(fresh.data.landingRegions.items) do if r.target.surfaceY==s.actor.feetY then back=r;break end end
assert(back)
local down=api('navigate_to_landing_region',back.target)
assert(down.valid and down.completed and down.evidence.settled)
return {placed=placed,up=up,down=down,goal=goal,back=back,sceneBefore=s.sceneId,sceneAfter=fresh.data.sceneId}
