
local s=api('get_player_state',{}); local p=s.player.position
local cx=math.floor(p.x/16); local y=math.floor((p.y+s.motion.playerHeight)/16)-1
for _,x in ipairs({cx,cx-1,cx+2}) do
  local target={x=x,y=y}; local t=api('inspect_tile',target)
  local overlaps=x*16<p.x+s.motion.playerWidth and (x+1)*16>p.x
  if not t.data.cell.hasTile and t.data.cell.liquidAmount==0 and not overlaps then
    local support=api('inspect_tile',{x=x,y=y+1})
    if support.data.cell.hasTile and support.data.cell.solid and not support.data.cell.actuated then return target end
  end
end
error('no baseline placement target')
