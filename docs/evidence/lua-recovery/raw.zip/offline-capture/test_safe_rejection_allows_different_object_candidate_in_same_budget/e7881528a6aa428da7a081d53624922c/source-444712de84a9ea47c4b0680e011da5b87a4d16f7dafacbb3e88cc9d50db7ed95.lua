
        local s=api('observe_scene',{}).data
        local first=api('place_object',s.objectPlacementCandidates.items[1].target)
        assert(first.status=='failed' and first.continuationAllowed)
        local second=api('place_object',s.objectPlacementCandidates.items[2].target)
        return {first=first,second=second}
        