-- 用几何图找 2 格宽空位，避免逐格 inspect
local inv = api('inspect_inventory', {mode = 'full'})
local wb = nil
for i = 1, #inv.data.inventory do
  local s = inv.data.inventory[i]
  if s and not s.empty and s.contentKey == 'Terraria/WorkBench' then wb = s break end
end
if wb == nil then return {error = 'no_workbench'} end
local key = wb.slot == 9 and 0 or wb.slot + 1
local scene = api('observe_scene', {})
local g = scene.data.geometry
local rows = g.rows
local ox, oy = g.originX, g.originY
local a = scene.data.actor
local ax = a.mapTile.x - ox
local ay = a.mapTile.y - oy
-- 找 @ 所在行附近，两个连续 '.' 且下方有实心
local spots = {}
for dy = -3, 2 do
  local r = ay + dy
  if r >= 2 and r <= #rows then
    for x = math.max(1, ax - 10), math.min(#rows[r] - 1, ax + 10) do
      local c1 = rows[r]:sub(x, x)
      local c2 = rows[r]:sub(x + 1, x + 1)
      local b1 = rows[r + 1]:sub(x, x)
      local b2 = rows[r + 1]:sub(x + 1, x + 1)
      if (c1 == '.' and c2 == '.') and (b1 == '#' or b2 == '#') then
        spots[#spots + 1] = {x = ox + x - 1, y = oy + r - 1, d = math.abs(x - ax) + math.abs(dy)}
      end
    end
  end
end
table.sort(spots, function(p, q) return p.d < q.d end)
local sel = api('select_hotbar_slot', {slot = key})
local tries = {}
local placed = nil
for i = 1, math.min(#spots, 3) do
  local s = spots[i]
  local p = api('place_object', {x = s.x, y = s.y})
  tries[#tries + 1] = {x = s.x, y = s.y, completed = p.completed, reason = p.reason,
    detail = p.reasonDetail, placed = p.evidence and p.evidence.placedByActor,
    consumed = p.evidence and p.evidence.consumedCount}
  if p.completed then placed = s break end
end
local inv2 = api('inspect_inventory', {mode = 'full'})
local left = 0
for i = 1, #inv2.data.inventory do
  local it = inv2.data.inventory[i]
  if it and not it.empty and it.contentKey == 'Terraria/WorkBench' then left = left + it.stack end
end
local after = api('observe_scene', {})
local wbs = {}
for i = 1, #after.data.objects.items do
  local o = after.data.objects.items[i]
  if o.kind == 'workbench' then wbs[#wbs + 1] = o.observedBounds end
end
return {spots = #spots, top3 = {table.unpack(spots, 1, math.min(#spots, 3))},
  selected = sel and sel.completed, tries = tries, placed = placed,
  workbenchLeft = left, workbenchesAfter = wbs, actorTile = {x = ax + ox, y = ay + oy}}
