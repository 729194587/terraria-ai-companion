-- 再砍几棵树攒够木头，顺便捡地上的
local function wood()
  local inv = api('inspect_inventory', {mode = 'full'})
  local n = 0
  for i = 1, #inv.data.inventory do
    local it = inv.data.inventory[i]
    if it and it.contentKey == 'Terraria/Wood' then n = n + it.stack end
  end
  return n
end
local start = wood()
local log = {}
for round = 1, 4 do
  if wood() >= 12 then break end
  local scene = api('observe_scene', {})
  local tree = nil
  for i = 1, #scene.data.objects.items do
    local o = scene.data.objects.items[i]
    if o.kind == 'tree_component' and o.observedTileCount > 4 then tree = o break end
  end
  if tree == nil then log[#log + 1] = {round = round, note = 'no_tree'} break end
  local bx = tree.observedBounds.x + math.floor(tree.observedBounds.width / 2)
  local by = tree.observedBounds.y + tree.observedBounds.height - 1
  local nav = api('navigate_to_x', {targetX = bx * 16 - 24})
  api('select_hotbar_slot', {slot = 3})
  local m = api('mine_tile', {x = bx, y = by})
  -- 捡地上的木头
  local drops = api('scan_entities', {category = 'item', radius = 300, maxResults = 12})
  local picked = 0
  for i = 1, #drops.data.items do
    local it = drops.data.items[i]
    if it.details and it.details.contentKey == 'Terraria/Wood' then
      api('navigate_to_x', {targetX = it.centerWorldPixels.x - 10})
      picked = picked + 1
      if picked >= 2 then break end
    end
  end
  log[#log + 1] = {round = round, tree = {x = bx, y = by}, mine = m.completed,
    reason = m.reason, wood = wood(), picked = picked}
end
return {start = start, endWood = wood(), log = log}
