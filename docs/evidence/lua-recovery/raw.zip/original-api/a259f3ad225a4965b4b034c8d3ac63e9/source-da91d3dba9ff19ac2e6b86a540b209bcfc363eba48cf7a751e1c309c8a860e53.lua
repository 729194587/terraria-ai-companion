-- 放置工作台：选它，再用语义图的放置候选
local inv = api('inspect_inventory', {mode = 'full'})
local wb = nil
for i = 1, #inv.data.inventory do
  local s = inv.data.inventory[i]
  if s and not s.empty and s.contentKey == 'Terraria/WorkBench' then wb = s break end
end
if wb == nil then return {error = 'no_workbench'} end
local key = wb.slot == 9 and 0 or wb.slot + 1
local sel = api('select_hotbar_slot', {slot = key})
local scene = api('observe_scene', {})
local cands = scene.data.objectPlacementCandidates or {}
local place = nil
local used = nil
for i = 1, math.min(#(cands.items or {}), 4) do
  local c = cands.items[i]
  local p = api('place_object', {x = c.target.x, y = c.target.y})
  place = {valid = p.valid, completed = p.completed, status = p.status, reason = p.reason,
    reasonDetail = p.reasonDetail, evidence = p.evidence}
  used = c.target
  if p.completed then break end
end
local after = api('observe_scene', {})
local wbs = {}
for i = 1, #after.data.objects.items do
  local o = after.data.objects.items[i]
  if o.kind == 'workbench' then wbs[#wbs + 1] = o.observedBounds end
end
local inv2 = api('inspect_inventory', {mode = 'full'})
local left = 0
for i = 1, #inv2.data.inventory do
  local s = inv2.data.inventory[i]
  if s and not s.empty and s.contentKey == 'Terraria/WorkBench' then left = left + s.stack end
end
return {workbenchSlot = wb.slot, key = key, selected = sel and sel.completed,
  candidateCount = #(cands.items or {}), used = used, place = place,
  workbenchesAfter = wbs, workbenchLeft = left}
