-- 用现有木头查工作台配方并合成
local wb = api('resolve_content', {kind = 'item', query = 'Terraria/WorkBench'})
local tid = wb.data.candidates[1].typeId
local recipes = api('query_recipes', {resultType = tid})
local out = {workbenchTypeId = tid, matched = recipes.data.matchedCount, recipes = {}}
for i = 1, math.min(#recipes.data.items, 3) do
  local r = recipes.data.items[i]
  out.recipes[#out.recipes + 1] = {recipeId = r.recipeId, token = r.recipeToken,
    output = r.output, ingredients = r.ingredients, stations = r.stations, conditions = r.conditions}
end
if #recipes.data.items == 0 then return out end
local r = recipes.data.items[1]
local made = api('craft_recipe', {recipeId = r.recipeId, recipeToken = r.recipeToken, crafts = 1})
out.craft = {valid = made.valid, completed = made.completed, status = made.status, reason = made.reason,
  reasonDetail = made.reasonDetail, evidence = made.evidence}
local inv = api('inspect_inventory', {mode = 'full'})
local items = {}
for i = 1, #inv.data.inventory do
  local s = inv.data.inventory[i]
  if s and not s.empty then items[#items + 1] = {slot = s.slot, key = s.contentKey, stack = s.stack} end
end
out.afterItems = items
return out
