﻿param([string]$TModLoaderPath='D:/steam/steamapps/common/tModLoader')
$ErrorActionPreference='Stop'
$package=Join-Path $PSScriptRoot 'Mods/CompanionBridge.tmod'
if((Get-FileHash -LiteralPath $package).Hash -ne '79396EE80594A77CB6F35158667792EE80E15097EA8F5CF836A0B81FF3B90071'){throw 'Package changed; prepare a new isolated profile.'}
$enabled=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Mods/enabled.json') -Raw | ConvertFrom-Json
if(@($enabled|Where-Object {$_ -notin @('CompanionBridge','ModLoader')}).Count){throw 'G8.2 requires CompanionBridge and tModLoader only.'}
foreach($port in @(7777,18777,18779)){
    if(@(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue).Count){throw "Port $port is occupied; close the previous test before launch."}
}
$previousEnabled=$env:COMPANION_SERVER_AI
$previousPort=$env:COMPANION_AI_PORT
$env:COMPANION_SERVER_AI='1'
$env:COMPANION_AI_PORT='18779'
Push-Location $TModLoaderPath
try { & (Join-Path $TModLoaderPath 'start-tModLoader.bat') -tmlsavedirectory $PSScriptRoot -modpath (Join-Path $PSScriptRoot 'Mods') }
finally { Pop-Location; $env:COMPANION_SERVER_AI=$previousEnabled; $env:COMPANION_AI_PORT=$previousPort }