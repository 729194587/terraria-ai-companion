-- 读取语义图全貌
local s = api('observe_scene', {})
local d = s.data
local out = {
  bounds = d.bounds,
  origin = {x = d.map.originX, y = d.map.originY},
  objectCounts = d.objectCounts,
  coverage = d.coverage,
  sample = d.sample,
  objects = {},
  landings = {},
  placements = {},
  hazards = {},
  actor = d.actor,
}
for i = 1, math.min(#d.objects.items, 8) do
  local o = d.objects.items[i]
  out.objects[#out.objects + 1] = {kind = o.kind, key = o.contentKey, n = o.observedTileCount,
    complete = o.complete, b = o.observedBounds}
end
for i = 1, math.min(#d.landingRegions.items, 5) do
  out.landings[#out.landings + 1] = d.landingRegions.items[i]
end
for i = 1, math.min(#d.placementCandidates.items, 5) do
  out.placements[#out.placements + 1] = d.placementCandidates.items[i]
end
local ht = d.hazards.tiles or {}
for i = 1, math.min(#ht, 5) do out.hazards[#out.hazards + 1] = ht[i] end
out.mapRows = d.map.rows
out.geometryRows = d.geometry.rows
return out
