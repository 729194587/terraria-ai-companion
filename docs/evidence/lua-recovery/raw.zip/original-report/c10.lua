-- 精简版：只探测角色右侧几个位置，找 2 格宽空位放工作台
local inv = api('inspect_inventory', {mode = 'full'})
local wb = nil
for i = 1, #inv.data.inventory do
  local s = inv.data.inventory[i]
  if s and not s.empty and s.contentKey == 'Terraria/WorkBench' then wb = s break end
end
if wb == nil then return {error = 'no_workbench'} end
local key = wb.slot == 9 and 0 or wb.slot + 1
local scene = api('observe_scene', {})
local a = scene.data.actor
local cx, cy = a.mapTile.x, a.mapTile.y
local sel = api('select_hotbar_slot', {slot = key})
local tries = {}
local placed = nil
-- 只试 3 个位置：右侧 2、4 格，同高度
for _, dx in ipairs({2, 4, 6}) do
  local x, y = cx + dx, cy
  local l = api('inspect_tile', {x = x, y = y})
  if not l.data.cell.hasTile then
    local r = api('inspect_tile', {x = x + 1, y = y})
    local b = api('inspect_tile', {x = x, y = y + 1})
    if not r.data.cell.hasTile and b.data.cell.solid then
      local p = api('place_object', {x = x, y = y})
      tries[#tries + 1] = {x = x, y = y, completed = p.completed, reason = p.reason,
        detail = p.reasonDetail, placed = p.evidence and p.evidence.placedByActor,
        consumed = p.evidence and p.evidence.consumedCount}
      if p.completed then placed = {x = x, y = y} break end
    else
      tries[#tries + 1] = {x = x, y = y, skipped = 'not_2wide_or_no_floor'}
    end
  else
    tries[#tries + 1] = {x = x, y = y, skipped = 'occupied'}
  end
end
local inv2 = api('inspect_inventory', {mode = 'full'})
local left = 0
for i = 1, #inv2.data.inventory do
  local it = inv2.data.inventory[i]
  if it and not it.empty and it.contentKey == 'Terraria/WorkBench' then left = left + it.stack end
end
local after = api('observe_scene', {})
local wbs = {}
for i = 1, #after.data.objects.items do
  local o = after.data.objects.items[i]
  if o.kind == 'workbench' then wbs[#wbs + 1] = o.observedBounds end
end
return {actorTile = a.mapTile, selected = sel and sel.completed, tries = tries,
  placed = placed, workbenchLeft = left, workbenchesAfter = wbs}
