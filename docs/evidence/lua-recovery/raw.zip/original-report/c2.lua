-- 查背包与配方
local inv = api('inspect_inventory', {mode = 'full'})
local items = {}
for i = 1, #inv.data.inventory do
  local s = inv.data.inventory[i]
  if s and not s.empty then items[#items + 1] = {slot = s.slot, key = s.contentKey, stack = s.stack} end
end
local wb = api('resolve_content', {kind = 'item', query = 'Terraria/WorkBench'})
local out = {items = items, workbenchContent = wb.data}
if wb.data and wb.data.candidates and #wb.data.candidates > 0 then
  local recipes = api('query_recipes', {resultType = wb.data.candidates[1].typeId})
  out.recipes = recipes.data
end
return out
