-- 砍树取木头（用语义图的树候选）
local scene = api('observe_scene', {})
local tree = nil
for i = 1, #scene.data.objects.items do
  local o = scene.data.objects.items[i]
  if o.kind == 'tree_component' and o.observedTileCount > 4 then tree = o break end
end
if tree == nil then return {error = 'no_tree', objects = scene.data.objectCounts} end
local bx = tree.observedBounds.x + math.floor(tree.observedBounds.width / 2)
local by = tree.observedBounds.y + tree.observedBounds.height - 1
local nav = api('navigate_to_x', {targetX = bx * 16 - 24})
local sel = api('select_hotbar_slot', {slot = 3})
local m = api('mine_tile', {x = bx, y = by})
local function wood()
  local inv = api('inspect_inventory', {mode = 'full'})
  local n = 0
  for i = 1, #inv.data.inventory do
    local it = inv.data.inventory[i]
    if it and it.contentKey == 'Terraria/Wood' then n = n + it.stack end
  end
  return n
end
return {
  tree = {x = bx, y = by, n = tree.observedTileCount, b = tree.observedBounds},
  nav = nav and {completed = nav.completed, x = nav.evidence and nav.evidence.x},
  selected = sel and {completed = sel.completed},
  mine = {completed = m.completed, reason = m.reason, ticks = m.evidence and m.evidence.Ticks},
  wood = wood(),
}
