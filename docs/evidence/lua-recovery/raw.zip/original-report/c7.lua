-- 工作台是 2x1 家具，语义图的单格候选不适用；手工找 2 格宽空位
local inv = api('inspect_inventory', {mode = 'full'})
local wb = nil
for i = 1, #inv.data.inventory do
  local s = inv.data.inventory[i]
  if s and not s.empty and s.contentKey == 'Terraria/WorkBench' then wb = s break end
end
if wb == nil then return {error = 'no_workbench'} end
local key = wb.slot == 9 and 0 or wb.slot + 1
local scene = api('observe_scene', {})
local a = scene.data.actor
local cx, cy = a.mapTile.x, a.mapTile.y
local spots = {}
for dx = -8, 8 do
  for dy = -2, 2 do
    local x, y = cx + dx, cy + dy
    local l = api('inspect_tile', {x = x, y = y})
    local r = api('inspect_tile', {x = x + 1, y = y})
    local bl = api('inspect_tile', {x = x, y = y + 1})
    local br = api('inspect_tile', {x = x + 1, y = y + 1})
    if not l.data.cell.hasTile and not r.data.cell.hasTile
        and (bl.data.cell.solid or br.data.cell.solid) and l.data.cell.liquidAmount == 0 then
      spots[#spots + 1] = {x = x, y = y, dx = dx, dy = dy}
    end
  end
end
local sel = api('select_hotbar_slot', {slot = key})
local tries = {}
local placed = nil
for i = 1, math.min(#spots, 3) do
  local s = spots[i]
  local p = api('place_object', {x = s.x, y = s.y})
  tries[#tries + 1] = {x = s.x, y = s.y, completed = p.completed, reason = p.reason,
    detail = p.reasonDetail, evidence = p.evidence}
  if p.completed then placed = s break end
end
local inv2 = api('inspect_inventory', {mode = 'full'})
local left = 0
for i = 1, #inv2.data.inventory do
  local it = inv2.data.inventory[i]
  if it and not it.empty and it.contentKey == 'Terraria/WorkBench' then left = left + it.stack end
end
return {spots = #spots, firstSpots = {table.unpack(spots, 1, math.min(#spots, 3))},
  selected = sel and sel.completed, tries = tries, placed = placed, workbenchLeft = left}
