# observe_scene 体积分析（0.1.61 实测）

游戏已在 14:06 关闭，本文基于 13:47 归档的完整回执 `runs/20261029-scene/c1.json`（`observe_scene({})`，45×29，稀疏墓地场景）。官方基准 `docs/evidence/semantic-scene/summary.json` 记录完整场景 **16664 B**。

## 一、结论先说

**信息密度高，但有一半是"可推导的"和"重复的"。**

- 真实新增信息（语义图 + 对象 + 危险 + 候选）本身很紧凑，约 **6–7 KB**
- 可削减的冗余约 **4.5 KB（约 40%）**
- 官方基准说"一次查询替代 12 次旧 API"，这个收益是真的；但**单次载荷从 6.4 KB 涨到 16.7 KB**，模型每轮要多吃 10 KB

## 二、逐项拆解

### 1. 两张图 93% 重叠 ← 最大单项冗余（约 1.3 KB）

`map.rows` 和 `geometry.rows` 各 45×29=1305 字符。实测：

```
非语义位置两图字符相同: 1219 / 1305 (93%)
语义符号覆盖掉的几何字符: 83 格，其中实心 # 只有 0 格
```

也就是说 `map.rows` 里的 `T/W/$/N/@` 盖掉的都是 `.` 或 `=`，**没有一个盖住实心 `#`**。`geometry.rows` 完全可以由"`map.rows` + 语义符号对应的底层几何字符"推出来。

现在等于把同一张图发了两遍，只差 83 个字符。

**建议**：`geometry` 只返回与 `map` 不同的格子（区段列表），或让 `map` 用大写/小写区分"语义覆盖了实心/非实心"，取消 `geometry.rows`。

### 2. `validation` 文本每条重复（约 2.1 KB）

```
landing:   "shared_navigation_support; integer-pixel interval; reachability not evaluated"  ×12 = 948 B
placement: "empty, dry, known, player-clear, <=80px and solid cardinal neighbour; native rules not evaluated" ×12 = 1176 B
```

**这 2.1 KB 里，一个字的新信息都没有**——12 条候选的验证规则完全一样，只是重复了 12 遍。这是本轮最大的一笔纯浪费。

**建议**：规则文本提到层级的 `validationRules: {landing: "...", placement: "..."}`，每条候选只带 `ruleId`。

### 3. `coverage` 固定说明文本（445 B）

```
candidateScope  189 B
treeIdentity    127 B
objectScope     129 B
```

这三段是**每个世界、每次调用都一样的常量说明**。它们描述的是接口契约，应该放在文档/握手能力里，不该每次塞进回执。

实测数据只有 `unknownCells=0 / uninterpretedCollisionCells=0 / unknownNavigationCells=0 / geometryComplete=true / scannedTiles=1305`——**这 5 个字段加起来 11 字节**。

### 4. `geometry.rows` 有 15 行全空（52% 是空行）

29 行里 15 行是 45 个 `.`。`map.rows` 只有 2 行全空。

这两行区域根本没有任何东西，却按满宽 45 字符发送。全空行合计 675 B。

**建议**：空行用 `null` 或直接跳过，用 `bounds` + 行号恢复。

### 5. `objects` 的 `complete=false` 恒真

树 `complete` 文档明说"永远 false"。6 个 tree_component 全带 `complete:false`，是常量。可以改成只在 `true` 时出现。

## 三、体积占比（我这次截取的 6.6 KB 子集）

| 字段 | 字节 | 占比 |
|---|---:|---:|
| geometryRows | 1421 | 21.3% |
| mapRows | 1421 | 21.3% |
| objects | 1054 | 15.8% |
| landings | 1036 | 15.6% |
| coverage | 630 | 9.5% |
| placements | 402 | 6.0% |
| actor + counts + sample + bounds | 529 | 7.9% |
| hazards（本场景空） | 2 | 0.0% |

完整默认参数（`maxObjects=16, maxRegions=12, maxPlacements=12`）估算：

```
maps       2842
objects    2128   (16 × 133)
landings   2448   (12 × 204)
placements 2388   (12 × 199)
coverage    630
其余       ~800
合计    ~11236 B  (稀疏场景)
```

官方基准的 **16664 B** 是对象/候选更密的场景。

## 四、如果按建议改，能省多少

| 措施 | 省 |
|---|---:|
| 去掉 `geometry.rows` 冗余部分 | ~1300 B |
| `validation` 提取成规则表 | ~2124 B |
| `coverage` 说明文本移到握手 | ~445 B |
| 全空行压缩 | ~675 B |
| **合计** | **~4544 B（约 40%）** |

改完 16.7 KB → **约 12 KB**，而且**信息量一点不减**。

## 五、我不建议砍的部分

这几块看着大，但都是真正在用的：

- **`landingRegions.target`**：三个整数直接能喂 `navigate_to_landing_region`。以前我要自己做 28 次坐标运算（官方基准的原话），现在 0 次。**这是最值钱的一层。**
- **`objects[].observedBounds`**：树/矿/掉落的位置，没有它我得自己扫。
- **`map.rows`**：语义标签的可视化，虽然占 1.4 KB，但它是我"一眼看懂场景"的唯一途径。

## 六、更根本的一个问题

体积只是表象。**真正的问题是：`geometry.rows` 我拿到了也解析不了。**

Lua 沙箱没有 `string` 库（`string.sub` 是 nil，`row:sub()` 被移除），所以 45 字符的行对我来说是**不能算的死数据**——我只能肉眼读，然后手写坐标。想程序化找"两个连续 `.` 且下方 `#`"，做不到，只能逐格 `inspect_tile`，20 次预算立刻撞墙。

所以这轮放置工作台我试了 8 次。

**如果只能改一件事**：给沙箱加 `string.sub / string.byte / string.find`。加了之后 45×29 的图我能在 Lua 里直接算，放置候选、路径检查、危险邻接全都能自己推——**这比砍体积有用得多**。

## 证据
- 完整回执：`runs/20261029-scene/c1.json`
- 官方基准：`docs/evidence/semantic-scene/summary.json`（`bytes.newScene = 16664`）
- 分析脚本输出见本次会话记录
