# 2026-10-29 · 0.1.61 实机验收：语义场景 / 配方合成 / 工作台放置

## 环境
- 包版本 `CompanionBridge/build.txt` = **0.1.61**
- 新增提交：`0dc74bd` 分层语义场景与行动候选、`7277c4b` 原生配方查询与合成、`cf8c732` 原生工作台放置、`a207fae` 对象取消时保留 unknown
- 世界：`63c7c06e…`，actor slot 254，`server_ai_scene_v1` + `server_ai_crafting_v1` + `server_ai_place_object_workbench_v1` 全部可用
- 桥：`runs/tools/bridge.py`（127.0.0.1:18780 → 18779）

## 1. observe_scene ✅
一次调用返回 22 个顶层字段：`map / geometry / hazards / objects / landingRegions / placementCandidates / objectPlacementCandidates / coverage / objectCounts / sample` 等。

实测值：
- `bounds` 2083..2127 × 193..221（45×29），`unknownCells=0`、`uninterpretedCollisionCells=0`、`unknownNavigationCells=0`、`scannedTiles=1305`
- `sample.elapsedMilliseconds=6.906`、`sameGameUpdate=true`
- `objectCounts.observed`：`tree_component=6`、`drop=4`、`workbench=1`、`npc=1`
- `landingRegions` 带 `feetDeltaY`（0/+16/-16）和 `target{minPlayerLeftX,maxPlayerLeftX,surfaceY}`，可直接喂 `navigate_to_landing_region`
- `placementCandidates` 只给单格保守候选（`solidNeighbor` + ≤80px）

地图可读性（`map.rows`，`@`=自己）：
```
208 ...T..TT......TTT.TT..@.......h#########1....
209 ...T...T.......T...T.......#.################
210 ..TT..TT.WW....TT..T..#######################
211 ##############.#########.##.#################
```
树干 `T`、工作台 `W`、掉落 `$`、NPC `N` 同图显示，比上一版 `observe_terrain` 的纯碰撞图信息密度高一个量级。

## 2. query_recipes / craft_recipe ✅
空背包时 `query_recipes(resultType=36)` → `matchedCount=0`（正确，没木头）。砍够木头后：
- 工作台配方 `recipeId=903`、10 Wood → 1 WorkBench，`native_recipe_crafted_and_received`、`inventoryVerified=true`、`completedCrafts=1`、`producedCount=1`、`batches[].consumed=[{typeId:9,count:10}]`
- 木剑配方 `recipeId=1523`、7 Wood + 邻接 `Terraria/WorkBenches`（`adjacent=true`）→ 1 WoodenSword，同样 `inventoryVerified=true`

`stations[].adjacent` 是真实状态，`conditions=[]` 表示无条件。`recipeToken` 是长哈希，跨调用仍有效（同一 world/代次内）。

## 3. place_object ✅（但成本高）
成功：`place_object({x=2091,y=210})` → `native_object_placed_and_consumed`、`placedByActor=true`、`consumedCount=1`、`remainingStack=0`、`Ticks=15`、`Starts=1`、`Attempts=1`、`footprint{2×1}`、`fullFootprintVerified=true`，之后 `observe_scene` 立刻看到 `workbench` 在 (2091,210)。

失败序列（全部 `mutationAttempted=false`、`effectStatus=not_started`）：
| 目标 | reason | 原因 |
|---|---|---|
| (2102,210) | `object_footprint_occupied` | 语义图 `placementCandidates` 给的是**单格**候选，工作台是 2×1 |
| (2092,210) 第一次 | `out_of_conservative_80_pixel_reach` | 离 AI 太远 |
| (2092,210) 走近后 | `object_player_collision` | 走到的位置正好压住 2×1 footprint |
| (2103,210) 挖装饰 | `invalid_tool` → `unsupported_target` | 槽 6 是工作台；换铜镐后 `Plants2`/`Torches` 不在 `mine_tile` 白名单 |

最终成功点 (2091,210) 是靠 `scan_tiles` 人工扫描找出来的。

## 4. 卡点清单（按影响排序）

1. **`placementCandidates` 与 `place_object` 语义不匹配**：候选按单格给（`solidNeighbor` 单格），`place_object` 按对象 footprint 校验。工作台 2×1，候选 3 个全部无效。要放家具必须自己扫两格空位 + 下方实心 + 避开自身 + 80px 内。
2. **`place_object` 失败无 `reasonDetail`**：`object_footprint_occupied` / `object_player_collision` / `out_of_conservative_80_pixel_reach` 全是 `reasonDetail=null`。挖土失败时反而给了可读原因（`镐 35，造成 0 点伤害`）。同一族接口的可读性不一致。
3. **失败后同一程序内后续动作全变 `previous_action_failed`**：`place_object` 一次失败后，后面几次尝试直接被挡，无法在同一 Lua 程序里"换个位置再试"。必须拆成多个程序提交。
4. **Lua 沙箱没有 `string` 库**：`string.sub` → `attempt to index a nil value (global 'string')`，字符串方法 `row:sub()` 也被移除。想在 Lua 里解析 `geometry.rows` / `map.rows` 做空间推理，**做不到**——只能逐格 `inspect_tile`，而 `inspect_tile` 每次耗一个 call 预算（默认 20，本次直接 `call_limit` 撞墙）。
5. **`geometry` 没有 `originX/originY`**：原点只在 `map.originX/originY`。文档写"`map.rows` 和 `geometry.rows` 各 29 行"，但没说几何图的坐标从哪取，第一次写错报 `attempt to perform arithmetic on a nil value (local 'ox')`。
6. **`mine_tile` 不能清理装饰物**：`Terraria/Plants2`(73)、`Terraria/Torches`(4) 报 `unsupported_target`，提示"目标不在当前工具范围内"。想腾出 2×1 空位时这条路走不通。
7. **call 预算偏紧**：一次 `observe_scene` 已给全图，但图上没有的细节（哪个格子是什么内容键）只能 `inspect_tile`，20 次预算扫不满 45 格。

## 5. 我实际用起来的感觉
- **语义图是这一轮最大的跃迁**。以前要拼 `observe_terrain` + `scan_tiles` + `scan_entities` 三份数据，现在一张图加四个列表就够判断"那边有树、脚下有工作台、右边有掉落、附近有 NPC"。
- **合成链通了**，而且是真扣料、真进包、`inventoryVerified` 可核。这是第一次能自己"造东西"。
- **放置链通了，但不好用**。能力有，决策空间没给——候选和动作的坐标语义不一致，失败原因不可读，失败后不能在同一程序里换位置重试。这三条叠起来，放一个工作台我试了 8 次、提交了 6 个 Lua 程序。
- 最想要的下一件事：`placementCandidates` 按**对象 footprint** 给候选（或者给 `place_object` 传 `objectType` 让它自己找位置），以及失败后允许同一程序内继续尝试。

## 证据
`runs/20261029-scene/`：`c1–c17.lua`、`c1–c17.json`、`geo.json`、`geo3–geo8.json`
