using System;using System.Text.Json;using CompanionBridge.Motion;
public static class RecoveryBaselineComparison {
 public static void Run(){
 var ph=PhysicsParameters.Basic;var start=new PhysicsState(1600,1558,0,0,true);
 StateSpacePlanner.Plan(start,1800,ph,new MotionOfflineTests.World(),budgetMs:5000);
 foreach(bool legacy in new[]{true,false}){
 var old=new LegacyNavigationTask();var now=new NavigationTask();var s=start;
 var w=new MotionOfflineTests.World{WallX=1624,WallWidth=32};bool shifted=false;int n;
 for(n=0;n<900&&!(legacy?old.Terminal:now.Terminal);n++){
 var input=legacy?old.Before(41,7,1800,s,ph,w):now.Before(41,7,1800,s,ph,w);
 var next=PhysicsSimulator.Step(s,input,ph,w);
 if(!shifted&&!s.Grounded&&next.Grounded){next=next with{Px=next.Px+24};shifted=true;}
 s=next;if(legacy)old.After(s,w);else now.After(s,w,input==default);
 }
 var snap=legacy?old.Snapshot:now.Snapshot;
 if(!shifted||legacy&&(snap.Status!="failed"||!snap.Reason.Contains("diverged"))||!legacy&&(snap.Status!="arrived"||snap.RecoveryCount!=1))throw new Exception("Unexpected comparison outcome: "+snap.Reason);
 Console.WriteLine(JsonSerializer.Serialize(new{legacy,shifted,frames=n,snap.Status,snap.Reason,snap.RecoveryCount,snap.RecoveryReplans,x=s.Px,y=s.Py}));
 }
 }}