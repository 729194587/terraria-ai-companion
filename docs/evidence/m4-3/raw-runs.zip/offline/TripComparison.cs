using System;using System.Text.Json;using CompanionBridge.Motion;
public static class TripComparison{public static void Run(){foreach(bool legacy in new[]{true,false}){
 var old=new LegacyNavigationTask();var now=new NavigationTask();var world=new NavigationTripTests.Alcove();
 var s=new PhysicsState(1620,1558,0,0,true);float min=s.Px;int n=0;
 StateSpacePlanner.Plan(s,1820,PhysicsParameters.Basic,world,budgetMs:5000);
 for(;n<=1800&&!(legacy?old.Terminal:now.Terminal);n++){
 var input=legacy?old.Before(1,1,1820,s,PhysicsParameters.Basic,world):now.Before(1,1,1820,s,PhysicsParameters.Basic,world);
 s=PhysicsSimulator.Step(s,input,PhysicsParameters.Basic,world);min=Math.Min(min,s.Px);
 if(legacy)old.After(s,world,input==default);else now.After(s,world,input==default);
 }var snap=legacy?old.Snapshot:now.Snapshot;
 if(legacy&&snap.Status=="arrived"||!legacy&&snap.Status!="arrived")throw new Exception("Comparison unexpectedly changed: "+snap.Reason);
 Console.WriteLine(JsonSerializer.Serialize(new{legacy,frames=n,minX=min,x=s.Px,snap.Status,snap.Reason,snap.DetourCheckpoints,snap.PlanNumber}));
 }}}