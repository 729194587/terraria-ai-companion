param([switch]$TripOnly,[switch]$RecoveryOnly, [switch]$PlannerOnly, [switch]$SafeGroundWalkOnly, [switch]$MiningSupportOnly, [switch]$MotionOnly, [string]$ObservationSamplePath, [switch]$LandingBudgetAudit,
    [int]$BudgetRepetitions = 100, [switch]$BudgetColdOnly, [switch]$LandingProtocolHost, [switch]$LandingOnly, [switch]$AuthorityNetworkOnly,
    [switch]$InventoryOnly, [switch]$BridgeOnly, [switch]$ServerReadsOnly, [switch]$NavigationOnly,[switch]$SceneOnly,[switch]$VerticalOnly)
$ErrorActionPreference = 'Stop'
$repo = Split-Path 'D:/Agent Project/terraria-ai-companion/tests' -Parent
# PowerShell 7.4+ uses .NET 8+; compile the actual IPC sources without Terraria.
$sources = @(
    (Join-Path $repo 'CompanionBridge/AiChatInput.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'AiChatOfflineTests.cs'),
    (Join-Path $repo 'CompanionBridge/AtomicParameters.cs'),
    (Join-Path $repo 'CompanionBridge/SceneLayers.cs'),
    (Join-Path $repo 'CompanionBridge/AtomicAuthority.cs'),
    (Join-Path $repo 'CompanionBridge/Common/Systems/NativeAuthorityWorld.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'AtomicAuthorityOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'AuthorityNetworkStubs.cs'),
    (Join-Path $repo 'CompanionBridge/HotbarSlots.cs'),
    (Join-Path $repo 'CompanionBridge/ItemAim.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/PlatformDropAction.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'AtomicOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'PlatformDropOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'LandingNavigationOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'AtomicGameOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'AtomicExtensionsOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'AtomicFoundationsOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'InventoryOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'ServerAiSharedReadTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'LocalInputOfflineTests.cs'),
    (Join-Path $repo 'CompanionBridge/Common/Systems/AtomicOperations.cs'),
    (Join-Path $repo 'CompanionBridge/Common/Systems/AtomicInventory.cs'),
    (Join-Path $repo 'CompanionBridge/Common/Systems/AtomicQueries.cs'),
    (Join-Path $repo 'CompanionBridge/ControlState.cs'),
    (Join-Path $repo 'CompanionBridge/GameMessageCapture.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'GameMessageOfflineTests.cs'),
    (Join-Path $repo 'CompanionBridge/ObservationSnapshot.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'ObservationOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'DeathLifecycleOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'BoundedMovementOfflineTests.cs'),
    (Join-Path $repo 'CompanionBridge/TerrainSnapshot.cs'),
    (Join-Path $repo 'CompanionBridge/SceneGeometry.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'SceneGeometryTests.cs'),
    (Join-Path $repo 'CompanionBridge/EntitySnapshot.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/PhysicsSimulator.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/NavigationBuffPolicy.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/MotionSupport.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/MiningSupportImpact.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'MiningSupportImpactTests.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/LocalMotionController.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/StateSpacePlanner.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/SafeGroundWalk.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'SafeGroundWalkTests.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/NavigationTask.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/NavigationFailureMemory.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/NavigationTripProgress.cs'),
    (Join-Path $repo 'CompanionBridge/Motion/NavigationDiagnostics.cs'),
    (Join-Path $repo 'CompanionBridge/TcpControlServer.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'BridgeOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'MotionOfflineTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'PlannerCorrectnessTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'VerticalNavigationTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'NavigationLandingConfirmationTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'NavigationRecoveryTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'NavigationTripTests.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'NavigationPerceptionTests.cs'),
    (Join-Path $repo 'CompanionBridge/Common/Players/CompanionPlayer.cs'),
    (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'PlayerHookOfflineTests.cs')
)
$references = Get-ChildItem (Join-Path $PSHOME 'ref') -Filter '*.dll' | Select-Object -ExpandProperty FullName
if ($AuthorityNetworkOnly) {
    $sources += (Join-Path $repo 'CompanionBridge/Common/Systems/AtomicMultiplayer.cs')
    $sources += (Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'AuthorityNetworkOfflineTests.cs')
    Add-Type -Path $sources -ReferencedAssemblies $references -CompilerOptions '/define:ATOMIC_NETWORK_TESTS'
    [AuthorityNetworkOfflineTests]::Run()
    return
}
$sources += 'D:/Agent Project/terraria-ai-companion/.local/m4-3-audit/LegacyNavigationTask.cs'
$sources += 'D:/Agent Project/terraria-ai-companion/.local/m4-3-audit/TripComparison.cs'
Add-Type -Path $sources -ReferencedAssemblies $references
[TripComparison]::Run(); return
if ($TripOnly) { [NavigationTripTests]::Run(); return }
if ($RecoveryOnly) { [NavigationRecoveryTests]::Run(); return }
if ($PlannerOnly) { [PlannerCorrectnessTests]::Run(); return }
if ($SafeGroundWalkOnly) { [SafeGroundWalkTests]::Run(); return }
if ($MiningSupportOnly) { [MiningSupportImpactTests]::Run((Join-Path 'D:/Agent Project/terraria-ai-companion/tests' 'fixtures/mining-support-play2.json')); return }
if ($SceneOnly) { [SceneGeometryTests]::Run(); return }
if ($VerticalOnly) { [VerticalNavigationTests]::Run(); return }
if ($NavigationOnly) { [NavigationTripTests]::Run(); [NavigationRecoveryTests]::Run(); [PlannerCorrectnessTests]::Run(); [NavigationPerceptionTests]::Run(); [NavigationLandingConfirmationTests]::Run(); [MotionOfflineTests]::Run(); [PlayerHookOfflineTests]::Run(); return }
if ($ServerReadsOnly) { [ServerAiSharedReadTests]::Run(); [AtomicExtensionsOfflineTests]::Run(); return }
if ($BridgeOnly) { [AiChatOfflineTests]::Run(); [BridgeOfflineTests]::Run(); [PlayerHookOfflineTests]::Run(); [LocalInputOfflineTests]::Run(); [DeathLifecycleOfflineTests]::Run(); return }
if ($InventoryOnly) { [InventoryOfflineTests]::Run(); return }
if ($LandingProtocolHost) { [LandingNavigationOfflineTests]::RunProtocolHost(); return }
if ($LandingOnly) { [LandingNavigationOfflineTests]::Run(); return }
if ($LandingBudgetAudit) { [MotionOfflineTests]::AuditLandingBudget($BudgetRepetitions, $BudgetColdOnly.IsPresent); return }
if (!$MotionOnly) { [AtomicOfflineTests]::Run(); [BridgeOfflineTests]::Run(); [ObservationOfflineTests]::Run(); [DeathLifecycleOfflineTests]::Run(); [GameMessageOfflineTests]::Run(); [BoundedMovementOfflineTests]::Run() }
if ($ObservationSamplePath -and !$MotionOnly) {
    [System.IO.File]::WriteAllText($ObservationSamplePath, [ObservationOfflineTests]::SampleJson,
        [System.Text.UTF8Encoding]::new($false))
}
[MotionOfflineTests]::Run()
[PlayerHookOfflineTests]::Run()
[AtomicGameOfflineTests]::Run()
[AtomicExtensionsOfflineTests]::Run()
[AtomicFoundationsOfflineTests]::Run()
[InventoryOfflineTests]::Run()
[LocalInputOfflineTests]::Run()
[AtomicAuthorityOfflineTests]::Run()

[LandingNavigationOfflineTests]::Run()

[PlatformDropOfflineTests]::Run()
