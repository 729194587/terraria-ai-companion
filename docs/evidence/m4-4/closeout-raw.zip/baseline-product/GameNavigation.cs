using System;
using System.Diagnostics;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using CompanionBridge.Common.Systems;

namespace CompanionBridge.Motion;

internal sealed class NativeNavigation
{
    internal LocalMotionController Controller { get; } = new();
    internal NavigationTask Task { get; }
    private readonly NavigationDiagnostics Diagnostics;
    internal NavigationSnapshot Snapshot => CoreSnapshot with {Mobility=_profile};
    private bool _navigation;
    private int _session, _generation;
    private NativeMotionWorld _world;
    private int _life;
    private bool _paired;
    private readonly MobilityTracker _mobility=new();
    private MobilityProfile _profile;
    private long _planRevision;
    private float _transitionSpeedLimit;
    private NavigationSnapshot CoreSnapshot=>_navigation?Task.Snapshot:Controller.Snapshot;
    private readonly bool _captureContacts;
    internal NativeNavigation(bool captureContacts=false,Action<string> diagnosticWriter=null,bool enableSafeGroundWalk=false,Func<PhysicsState,int> historicalPreference=null)
    {
        _captureContacts=captureContacts;
        Task=new(enableSafeGroundWalk,historicalPreference);
        Diagnostics=new(diagnosticWriter??(line=>ModContent.GetInstance<CompanionBridge>().Logger.Info(line)));
    }

    private PhysicsState State(Player p) => new(p.position.X, p.position.Y,
        p.velocity.X, p.velocity.Y, TerrainReader.Read(p).Grounded, p.jump, p.releaseJump);

    internal bool Ordinary(Player p) => OrdinaryRejection(p) == null;

    private string OrdinaryRejection(Player p,float transitionSpeedLimit=0)
    {
        var ph = Parameters(p);
        List<string> reasons = null;
        void Reject(bool condition, string reason)
        {
            if (condition) (reasons ??= new()).Add(reason);
        }
        foreach(var mod in ModLoader.Mods)
            Reject(mod.Name is not ("ModLoader" or "CompanionBridge"),"unvalidated_loaded_mod: "+mod.Name);
        Reject(p.mount.Active, "mount_active");
        Reject(p.gravDir != 1, "unsupported_gravity");
        Reject(p.wet, "wet");
        Reject(p.pulley, "pulley");
        Reject(p.grapCount != 0, "grappling");
        Reject(p.webbed, "webbed");
        Reject(p.stoned, "stoned");
        Reject(p.frozen, "frozen");
        Reject(p.sliding, "sliding");
        Reject(p.autoJump, "auto_jump");
        Reject(p.windPushed, "wind_pushed");
        Reject(p.slippy || p.slippy2, "slippery");
        Reject(p.sticky, "sticky");
        Reject(p.powerrun, "power_run");
        Reject(p.AnyExtraJumpUsable(), "extra_jump_usable");
        Reject(p.wingsLogic != 0, "functional_wings");
        Reject(p.rocketBoots != 0, "rocket_boots");
        Reject(p.itemAnimation != 0, "item_animation");
        Reject(p.width != 20 || p.height != 42, "unsupported_body_size");
        Reject(!(Math.Abs(p.velocity.X) <= Math.Max(p.HasBuff(BuffID.Swiftness)?3.95f:3.2f,transitionSpeedLimit)), "unsupported_horizontal_velocity");
        var expected=p.HasBuff(BuffID.Swiftness)?PhysicsParameters.Swiftness:PhysicsParameters.Basic;
        if (!ph.Matches(expected)) Reject(true, $"unsupported_physics: {ph}");
        for (int i = 0; i < 10; i++)
            if (!p.armor[i].IsAir) Reject(true, $"equipment: slot={i}, type={p.armor[i].type}, name={p.armor[i].Name}");
        for (int i = 0; i < p.buffTime.Length; i++)
        {
            int type = p.buffType[i];
            // Only resolve names for rejected effects; no per-tick string work for allowed buffs.
            if (NavigationBuffPolicy.Rejection(type, p.buffTime[i], i, null) == null) continue;
            string key = BuffLoader.GetBuff(type)?.FullName ?? "Terraria/" + BuffID.Search.GetName(type);
            Reject(true, NavigationBuffPolicy.Rejection(type, p.buffTime[i], i, key));
        }
        return reasons == null ? null : string.Join("; ", reasons);
    }

    private PhysicsParameters Parameters(Player p) => new(p.runAcceleration, p.maxRunSpeed,
        p.accRunSpeed, p.runSlowdown, p.gravity, p.maxFallSpeed, Player.jumpSpeed, Player.jumpHeight);

    internal PhysicsInput Before(Player p, int session, int direction, int generation, float? targetX = null,
        LandingRegion region = null)
    {
        _paired = false;
        _navigation = targetX.HasValue || region != null;
        if (!_navigation)
        {
            Task.Cancel(); Diagnostics.Observe(Task.Snapshot);
            Controller.Begin(session, direction, generation);
        }
        else
        {
            Controller.Cancel();
            if (region != null) Task.Begin(session, generation, region, State(p));
            else Task.Begin(session, generation, targetX.Value, State(p));
        }
        var ph=Parameters(p);
        bool sameProfileScope=_profile?.Session==session&&_profile?.Generation==generation;
        if(sameProfileScope&&_profile.Supported&&_profile.Variant=="vanilla_swiftness"
            &&!p.HasBuff(BuffID.Swiftness)&&ph.IsBasic)_transitionSpeedLimit=3.95f;
        if(!sameProfileScope||Math.Abs(p.velocity.X)<=3.2f)_transitionSpeedLimit=0;
        string rejection = OrdinaryRejection(p,_transitionSpeedLimit);
        _profile=_mobility.Sample(ph,p.width,p.height,p.HasBuff(BuffID.Swiftness),
            rejection==null?Array.Empty<string>():new[]{rejection},Main.GameUpdateCount,session,generation);
        if(!_profile.Supported)return Fail("unsupported navigation state: "+string.Join("; ",_profile.UnsupportedEffects));
        if (_session != session || _generation != generation) _life = p.statLife;
        _session = session; _generation = generation;
        if (p.statLife < _life) return Fail("life decreased");
        _life = p.statLife;
        var state = State(p);
        if(_planRevision!=_profile.Revision)
        {
            if(_navigation)Task.InvalidateMobility(state,_profile.Revision);
            else Controller.Cancel();
        }
        _planRevision=_profile.Revision;
        _world = new NativeMotionWorld(state,_captureContacts);
        long started = Stopwatch.GetTimestamp();
        var input = _navigation
            ? region != null ? Task.Before(session, generation, region, state, ph, _world)
                : Task.Before(session, generation, targetX.Value, state, ph, _world)
            : Controller.Before(session, direction, state, ph, _world, generation);
        if (Stopwatch.GetElapsedTime(started).TotalMilliseconds > 50)
            return Fail("local prediction exceeded 50ms budget");
        if (_navigation) Diagnostics.Observe(Snapshot);
        _paired = true;
        return input;
    }

    internal void After(Player p)
    {
        if (!_paired) return;
        _paired = false;
        if (p.statLife < _life || p.dead) { Fail("life decreased/dead"); return; }
        if (_navigation) { Task.After(State(p), _world, inputsReleased: !p.controlLeft && !p.controlRight && !p.controlJump
            && !p.controlDown && !p.controlUp && !p.controlUseItem && !p.controlUseTile); Diagnostics.Observe(Snapshot); }
        else Controller.After(State(p), _world);
    }

    private PhysicsInput Fail(string reason)
    {
        var input = _navigation ? Task.Fail(reason) : Controller.Fail(reason);
        if (_navigation) Diagnostics.Observe(Snapshot);
        return input;
    }

    internal void Cancel()
    {
        _mobility.Reset();_profile=null;_planRevision=0;_transitionSpeedLimit=0;
        _paired = false; _world = null; _session = _generation = 0;
        Task.Cancel(); Diagnostics.Observe(Task.Snapshot); _navigation = false;
        Controller.Cancel();
    }
}

// Existing human callers retain their process-local instance and API.
internal static class GameNavigation
{
    private static readonly NativeNavigation instance = new();
    internal static LocalMotionController Controller => instance.Controller;
    internal static NavigationTask Task => instance.Task;
    internal static NavigationSnapshot Snapshot => instance.Snapshot;
    internal static bool Ordinary(Player p) => instance.Ordinary(p);
    internal static PhysicsInput Before(Player p, int session, int direction, int generation, float? targetX = null, LandingRegion region = null)
        => instance.Before(p, session, direction, generation, targetX, region);
    internal static void After(Player p) => instance.After(p);
    internal static void Cancel() => instance.Cancel();
}
