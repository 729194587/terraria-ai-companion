local report={steps=json.array(),observations=json.array(),reason='step_limit'}
for step=1,6 do
    local before=api('get_player_state',{})
    assert(before.valid)
    report.observations[#report.observations+1]=api('observe_terrain',{})
    local action=api('navigate_to_x',{targetX=before.player.position.x+-1*128})
    report.steps[#report.steps+1]={action=action,before=before}
    if not action.valid or not action.completed or action.endEvidenceStatus~='known' then report.reason='action_'..tostring(action.status); break end
end
report.after=api('observe_terrain',{})
return {report=report}