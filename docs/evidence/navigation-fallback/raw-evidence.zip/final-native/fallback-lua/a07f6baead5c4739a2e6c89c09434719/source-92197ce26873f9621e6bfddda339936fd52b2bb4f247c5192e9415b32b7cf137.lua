
local before=api('get_player_state',{})
local goal=before.player.position.x+32
local navigation=api('navigate_to_x',{targetX=goal})
if navigation.completed then return {navigation=navigation,alreadyArrived=true} end
assert(navigation.status=='failed' and navigation.continuationAllowed)
local scene=api('observe_scene',{layers={'geometry','hazards'}})
if scene.data.actor.dead or not scene.data.coverage.geometryComplete then return {stopped=true} end
local position=scene.data.actor.boundsWorldPixels
local direction=position.x<goal and 'right' or 'left'
local movement=api('move_input',{horizontal=direction,vertical='none',jumpHoldUpdates=8,maxUpdates=40})
local after=api('get_player_state',{})
return {navigation=navigation,movement=movement,startX=position.x,goalX=goal,
    finalX=after.player.position.x,moved=movement.completed and after.player.position.x>=goal}
