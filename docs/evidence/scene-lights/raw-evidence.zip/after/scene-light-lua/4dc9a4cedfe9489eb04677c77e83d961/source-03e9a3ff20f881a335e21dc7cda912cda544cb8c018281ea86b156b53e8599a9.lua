
local full=api('observe_scene',{})
local capped=api('observe_scene',{layers={'objects','map','hazards'},maxObjects=1,maxHazards=1})
local objects=api('observe_scene',{layers={'objects'},maxObjects=32})
local geometry=api('observe_scene',{layers={'geometry','landingRegions'}})
return {full=full,capped=capped,objects=objects,geometry=geometry}
