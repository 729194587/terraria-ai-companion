-- Trusted, inspectable Lua composition. Every game read/action uses the original api callback.
local cell_at, scene_supported = ...
local used = false
-- Pre-move center-distance envelope, not a realtime enemy avoidance guarantee.
-- Keep the old 96px standoff; allow 128px of relative motion/snapshot ageing,
-- plus the original navigator's 12px arrival tolerance. Fast/large enemies can exceed this heuristic.
local THREAT_STANDOFF = 96
local THREAT_MOTION_MARGIN = 128
local ARRIVAL_MARGIN = 12
local THREAT_MARGIN = THREAT_STANDOFF + THREAT_MOTION_MARGIN + ARRIVAL_MARGIN
local function abs(x) if x < 0 then return -x end return x end
local function min(a,b) if a < b then return a end return b end
local function max(a,b) if a > b then return a end return b end
local function integer(value, fallback, low, high)
    if value == nil then return fallback end
    assert(type(value) == 'number' and math.tointeger(value) and value >= low and value <= high,
        'explore: invalid bounded integer option')
    return math.tointeger(value)
end

-- Scene IDs and landing IDs expire with each observation. Memory contains only
-- confirmed world positions, never those IDs or an inferred traversal graph.
local function explore_scene(asked, maxSteps, stride, maxDistance)
    local report = {kind='exploration_report', mode='scene_landing_regions', status='stopped',
        reason='not_started', steps=json.array(), decisions=json.array(), landmarks=json.array(),
        distancePixels=0, distanceBasis='confirmed_endpoint_displacement_L1', reversals=0,
        noNovelSteps=0, memoryScope='this Lua run and bound actor only'}
    local direction = asked == 'left' and -1 or 1
    local visits = json.array()
    local function finish(reason)
        report.reason=reason
        log('explore stop='..reason..' steps='..tostring(#report.steps)..' distance='..tostring(report.distancePixels))
        return report
    end
    local function number(v) return type(v)=='number' and v==v and abs(v)<math.huge end
    local p=api('get_player_state',{})
    if not p.valid or not p.player or not p.player.position then return finish('player_unavailable') end
    local world,generation,slot=p.worldSessionId,p.actorGeneration,p.actorSlot
    if type(world)~='string' or not number(generation) or not number(slot)
        or p.player.source~='server_ai_player' then return finish('server_ai_identity_required') end
    report.identity={worldSessionId=world,actorGeneration=generation,actorSlot=slot}
    local function same(r)
        return r.valid==true and r.worldSessionId==world and r.actorGeneration==generation and r.actorSlot==slot
    end
    local function player_ok(r)
        local a,m=r.player,r.motion
        return same(r) and a and a.position and a.velocity and m and number(r.gameUpdate)
            and number(a.position.x) and number(a.position.y) and number(a.life)
            and a.source=='server_ai_player' and m.playerWidth==20 and m.playerHeight==42
            and m.grounded==true and m.supported==true and number(a.velocity.x) and number(a.velocity.y)
            and abs(a.velocity.x)<=0.1 and abs(a.velocity.y)<=0.1
    end
    if not player_ok(p) then return finish('unsupported_motion_state') end
    local function scene(afterTick)
        local s=api('observe_scene',{layers={'geometry','landingRegions','hazards'},maxRegions=24,maxHazards=64})
        if not same(s) or not number(s.gameUpdate) or s.gameUpdate<afterTick or type(s.data)~='table' then
            return nil,'observation_unavailable'
        end
        local d=s.data
        report.lastScene={sceneId=d.sceneId,gameUpdate=s.gameUpdate,observedAtUnixMs=s.observedAtUnixMs,
            coverage=d.coverage,landingRegions=d.landingRegions and {truncated=d.landingRegions.truncated,
                matchedCount=d.landingRegions.matchedCount,returnedCount=d.landingRegions.returnedCount}}
        if not d.actor or d.actor.navigationProfileSupported~=true then return nil,'unsupported_motion_state' end
        if d.actor.dead then return nil,'actor_unavailable' end
        if not d.geometry or not d.coverage or d.coverage.geometryComplete~=true
            or not d.landingRegions or type(d.landingRegions.items)~='table'
            or not d.hazards or not d.hazards.tiles or not d.hazards.entities
            or type(d.hazards.tiles.items)~='table' or type(d.hazards.entities.items)~='table' then
            return nil,'scene_coverage_unavailable'
        end
        if d.hazards.tiles.truncated~=false or d.hazards.entities.truncated~=false then
            return nil,'hazard_coverage_truncated'
        end
        local b=d.actor.boundsWorldPixels
        if not b or not number(b.x) or not number(b.y) or not number(d.actor.feetY)
            or b.width~=20 or b.height~=42 or abs(b.x-p.player.position.x)>0.5
            or abs(b.y-p.player.position.y)>0.5 or abs(d.actor.feetY-b.y-42)>0.5 then
            return nil,'observation_position_changed'
        end
        return s
    end
    local view,why=scene(p.gameUpdate)
    if not view then return finish(why) end
    local x,y=p.player.position.x,p.player.position.y
    report.start={x=x,y=y}; report.finish={x=x,y=y}
    report.visited={minX=x,maxX=x,minFeetY=y+42,maxFeetY=y+42,areas=visits,
        basis='confirmed_landings_only; ranges do not prove intervening coverage'}
    local function remember(px,feet,tick,sceneId)
        visits[#visits+1]={x=px,feetY=feet,gameUpdate=tick,sceneId=sceneId}
        local v=report.visited
        v.minX=min(v.minX,px);v.maxX=max(v.maxX,px)
        v.minFeetY=min(v.minFeetY,feet);v.maxFeetY=max(v.maxFeetY,feet)
    end
    remember(x,y+42,p.gameUpdate,view.data.sceneId)
    local function seen(low,high,feet)
        for _,v in ipairs(visits) do
            if abs(v.feetY-feet)<16 and v.x>low-24 and v.x<high+24 then return true end
        end
        return false
    end
    local function new_height(feet)
        for _,v in ipairs(visits) do if abs(v.feetY-feet)<16 then return false end end
        return true
    end
    -- Conservative snapshot envelope only; native prediction must still prove
    -- the real jump/braking trajectory, including hazards outside this rectangle.
    local function hazard(px,feet)
        local a=p.player.position
        local l,r=min(a.x,px)-6,max(a.x,px)+26
        local t,b=min(a.y,feet-42)-32,max(a.y+42,feet)+2
        local function intersects(x1,y1,x2,y2) return x1<r and x2>l and y1<b and y2>t end
        for _,h in ipairs(view.data.hazards.tiles.items) do
            if intersects(h.minX*16,h.y*16,(h.maxX+1)*16,(h.y+1)*16) then return true end
        end
        for _,h in ipairs(view.data.hazards.entities.items) do
            local q=h.boundsWorldPixels
            if not q or intersects(q.x,q.y,q.x+q.width,q.y+q.height) then return true end
        end
        return false
    end
    for step=1,maxSteps do
        if p.player.dead or p.player.life<=0 then return finish('actor_unavailable') end
        local allowance=min(stride,maxDistance-report.distancePixels-ARRIVAL_MARGIN)
        if allowance<32 then return finish('distance_limit') end
        local radius=allowance+THREAT_MARGIN
        local threat=api('scan_entities',{category='npc',npcFilter='hostile_creature',radius=radius,maxResults=1})
        if not same(threat) or not number(threat.gameUpdate) or threat.gameUpdate<view.gameUpdate
            or not threat.data or not number(threat.data.matchedCount) then return finish('entity_observation_unavailable') end
        local nearest=nil
        if threat.data.matchedCount>0 then
            local h=threat.data.items and threat.data.items[1]
            if not h or not number(h.distancePixels) or h.distancePixels<0 or h.distancePixels>radius then
                return finish('entity_observation_unavailable')
            end
            nearest=h.distancePixels;allowance=min(allowance,nearest-THREAT_MARGIN)
        end
        report.lastThreatCheck={phase='pre_move_snapshot',radiusPixels=radius,marginPixels=THREAT_MARGIN,
            permittedStepPixels=max(0,allowance),nearestDistancePixels=nearest or json.null,
            gameUpdate=threat.gameUpdate,observedAtUnixMs=threat.observedAtUnixMs}
        if allowance<32 then return finish('nearby_hostile') end
        local best=nil
        local candidates=json.array()
        local hadRevisit=false
        for _,region in ipairs(view.data.landingRegions.items) do
            local g=region.target
            if g and number(g.minPlayerLeftX) and number(g.maxPlayerLeftX) and number(g.surfaceY)
                and g.minPlayerLeftX<=g.maxPlayerLeftX then
                local dy=g.surfaceY-(p.player.position.y+42)
                local reach=allowance-abs(dy)
                local low=max(g.minPlayerLeftX,p.player.position.x-reach,0)
                local high=min(g.maxPlayerLeftX,p.player.position.x+reach)
                if asked=='right' then low=max(low,p.player.position.x) end
                if asked=='left' then high=min(high,p.player.position.x) end
                if reach>=0 and dy<=64 and low<=high then
                    for _,px in ipairs({max(low,min(high,p.player.position.x)),high,low}) do
                        local goal={minPlayerLeftX=max(low,px-4),maxPlayerLeftX=min(high,px+4),surfaceY=g.surfaceY}
                        local distance=abs(px-p.player.position.x)+abs(dy)
                        local revisit=seen(goal.minPlayerLeftX,goal.maxPlayerLeftX,g.surfaceY)
                        local rejected=revisit and 'visited_landing' or distance<16 and 'insufficient_progress'
                            or hazard(px,g.surfaceY) and 'observed_hazard' or nil
                        hadRevisit=hadRevisit or revisit
                        if #candidates<72 then candidates[#candidates+1]={targetRegion=goal,reason=rejected or 'native_plan_required'} end
                        local sign=px>p.player.position.x and 1 or px<p.player.position.x and -1 or 0
                        -- When already under an upper platform, keep current X
                        -- inside the goal so the navigator can use neutral ascent.
                        -- A few extra horizontal pixels must not force a lateral
                        -- jump inside a narrow shaft (its 24px progress gate).
                        local score=(new_height(g.surfaceY) and 1024 or 0)+distance+(sign==direction and 8 or 0)
                            +(sign==0 and dy<0 and 256 or 0)
                        if not rejected and (sign==0 or sign==direction or report.reversals<2)
                            and (not best or score>best.score) then
                            best={goal=goal,sourceRegion=region.target,sourceId=region.id,score=score,direction=sign}
                        end
                    end
                end
            end
        end
        report.decisions[#report.decisions+1]={step=step,sceneId=view.data.sceneId,gameUpdate=view.gameUpdate,
            targetRegion=best and best.goal or json.null,basis='unvisited_2d_landing_new_height_preferred_native_plan_required',candidates=candidates}
        if not best then
            if view.data.landingRegions.truncated then return finish('landing_candidates_truncated') end
            return finish(hadRevisit and 'no_unvisited_landing' or 'no_safe_landing_candidate')
        end
        if best.direction~=0 and best.direction~=direction then
            report.reversals=report.reversals+1;direction=best.direction
        end
        local before=p.player
        log('explore step='..tostring(step)..' feetY='..tostring(best.goal.surfaceY))
        local action=api('navigate_to_landing_region',best.goal)
        report.lastAction={actionId=action.actionId,status=action.status,reason=action.reason,
            reasonDetail=action.reasonDetail,endEvidenceStatus=action.endEvidenceStatus}
        if not action.valid or not action.completed or action.endEvidenceStatus~='known'
            or not action.endEvidence or action.endEvidence.inputsReleased~=true then
            return finish('action_'..tostring(action.status))
        end
        -- The dispatcher already verifies bound arrival/release. Independently
        -- compare the subsequent actual player AND scene; never count an ID or
        -- the candidate as visited before this observation boundary.
        p=api('get_player_state',{})
        if not player_ok(p) then return finish('player_observation_unavailable') end
        if p.player.dead or p.player.life<before.life then return finish('health_decreased') end
        local endTick=action.endEvidence.gameUpdate
        if not number(endTick) or p.gameUpdate<endTick then return finish('stale_progress_observation') end
        view,why=scene(p.gameUpdate)
        if not view then return finish(why) end
        local ax,ay=p.player.position.x,p.player.position.y
        local moved=abs(ax-before.position.x)+abs(ay-before.position.y)
        report.finish={x=ax,y=ay}
        if moved<16 then return finish('no_progress') end
        if ax<best.goal.minPlayerLeftX or ax>best.goal.maxPlayerLeftX or abs(ay+42-best.goal.surfaceY)>0.5 then
            return finish('landing_observation_mismatch')
        end
        if seen(ax,ax,ay+42) then return finish('revisited_landing') end
        remember(ax,ay+42,p.gameUpdate,view.data.sceneId)
        report.distancePixels=report.distancePixels+moved
        report.steps[#report.steps+1]={step=step,direction=best.direction,targetRegion=best.goal,
            sourceRegion=best.sourceRegion,sourceSceneId=report.decisions[#report.decisions].sceneId,
            actionId=action.actionId,endGameUpdate=endTick,fromX=before.position.x,fromY=before.position.y,
            toX=ax,toY=ay,feetY=ay+42,movedPixels=moved,newLanding=true,
            gameUpdate=p.gameUpdate,sceneId=view.data.sceneId,sceneGameUpdate=view.gameUpdate}
        log('explore progress='..tostring(moved)..' new_landing=true')
    end
    return finish('step_limit')
end

return function(options)
    assert(not used, 'explore: one loop per Lua run; do not reset exploration memory')
    used = true
    options = options or {}
    assert(type(options) == 'table', 'explore: options must be a table')
    for key in pairs(options) do
        assert(key == 'direction' or key == 'maxSteps' or key == 'stepPixels' or key == 'maxDistance',
            'explore: unexpected option')
    end
    local asked = options.direction or 'auto'
    assert(asked == 'auto' or asked == 'left' or asked == 'right', 'explore: direction is auto/left/right')
    local maxSteps = integer(options.maxSteps, 6, 1, 8)
    local stride = integer(options.stepPixels, 128, 64, 128)
    local maxDistance = integer(options.maxDistance, 768, 64, 1024)
    if scene_supported then return explore_scene(asked,maxSteps,stride,maxDistance) end
    local direction = asked == 'left' and -1 or 1
    local visits, landmarks, landmarkKeys = {}, {}, {}
    local report = {kind='exploration_report', status='stopped', reason='not_started',
        steps=json.array(), decisions=json.array(), landmarks=json.array(), distancePixels=0,
        reversals=0, noNovelSteps=0, memoryScope='this Lua run and bound actor only'}
    local function finish(reason)
        report.reason = reason
        report.landmarks = json.array(landmarks)
        log('explore stop=' .. reason .. ' steps=' .. tostring(#report.steps)
            .. ' distance=' .. tostring(report.distancePixels))
        return report
    end
    local function readPlayer()
        local r = api('get_player_state', {})
        if not r.valid or not r.player or not r.player.position then return nil end
        return r
    end
    local p = readPlayer()
    if not p then return finish('player_unavailable') end
    local world, generation, slot = p.worldSessionId, p.actorGeneration, p.actorSlot
    if type(world) ~= 'string' or type(generation) ~= 'number' or type(slot) ~= 'number'
        or p.player.source ~= 'server_ai_player' then return finish('server_ai_identity_required') end
    local function same(r)
        return r.valid and r.worldSessionId == world and r.actorGeneration == generation and r.actorSlot == slot
    end
    local view = api('observe_terrain', {})
    if not same(view) or not view.data or not view.data.terrain then return finish('observation_unavailable') end
    local x = p.player.position.x
    report.start = {x=x, y=p.player.position.y}
    report.finish = report.start
    report.identity = {worldSessionId=world, actorGeneration=generation, actorSlot=slot}
    report.visited = {minX=x, maxX=x}
    visits[math.floor(x/64)] = 1
    local content = api('resolve_content', {kind='tile', query='Terraria/Trees'})
    local treeType = nil
    if same(content) and content.data.status == 'ok' and #content.data.candidates == 1 then
        treeType = content.data.candidates[1].typeId
    end

    -- Conservative direction filter only. The original native navigator still plans and validates each move.
    -- Bounded 2D candidates: ordinary floor slopes/half blocks, low steps and <=3-tile gaps.
    -- This is not a route proof: native physics must validate the complete motion/braking tail.
    local function candidate(sign, distance)
        local t = view.data.terrain
        local function cell(tx,ty)
            local row = t.rows[ty-t.originY+1]
            if not row then return '?' end
            local index = tx-t.originX+1
            if index < 1 or index > #row then return '?' end
            -- Strings have no metatable in this sandbox: use the trusted grid helper.
            return cell_at(row, index, index)
        end
        local target = p.player.position.x + sign*distance
        if target < 0 then return nil, 'world_boundary' end
        local bucket = math.floor(target/64)
        if (visits[bucket] or 0) >= 2 then return nil, 'revisit_limit' end
        local feet = math.floor((p.player.position.y+t.playerHeight)/16)
        local first = math.floor(p.player.position.x/16)
        local last = math.floor((target+t.playerWidth-0.01)/16)
        if sign < 0 then first = math.floor(target/16); last = math.floor((p.player.position.x+t.playerWidth-0.01)/16) end
        local gap, previousSurface = 0, nil
        -- Follow surfaces in travel order. Each column uses the last observed
        -- support height; a whole segment need not remain at its starting altitude.
        local beginX, endX = first, last
        if sign < 0 then beginX, endX = last, first end
        for tx=beginX,endX,sign do
            local reference = previousSurface or feet
            for ty=reference-10,reference+5 do
                local c=cell(tx,ty)
                if c == '?' or c == '!' then return nil, 'unknown_or_hazard' end
            end
            local surface = nil
            for ty=reference-4,reference+4 do
                local c=cell(tx,ty)
                if c == '#' or c == '=' or c == 'h' or c == '1' or c == '2' then
                    if cell(tx,ty-1)=='.' and cell(tx,ty-2)=='.' and cell(tx,ty-3)=='.' then
                        surface = ty
                        break
                    end
                end
            end
            if surface then
                if previousSurface and abs(surface-previousSurface)>2 then
                    return nil, 'excessive_surface_change'
                end
                previousSurface=surface
                gap=0
            else
                -- A missing surface is only a gap if the body/jump corridor is empty.
                -- Never reinterpret a tall wall, ceiling slope or unsupported shape as a hole.
                for ty=reference-4,reference+4 do
                    if cell(tx,ty)~='.' then return nil, 'tall_obstacle_or_unsupported_shape' end
                end
                gap=gap+1
                if gap>3 or not previousSurface then return nil, 'gap_without_near_landing' end
            end
        end
        -- A target over a hole is not a candidate, even when its width is small.
        if gap>0 then return nil, 'gap_without_near_landing' end
        return target, 'local_candidate'
    end

    for step=1,maxSteps do
        local player, t = p.player, view.data.terrain
        if player.dead or player.life <= 0 then return finish('actor_unavailable') end
        if not t.grounded or not t.supported then return finish('unsupported_motion_state') end
        if report.distancePixels >= maxDistance then return finish('distance_limit') end
        local allowance=min(stride,maxDistance-report.distancePixels-ARRIVAL_MARGIN)
        if allowance < 32 then return finish('distance_limit') end
        -- One radial scan covers either direction and every shorter candidate in this iteration.
        -- Results are nearest-first before truncation, so the first hostile bounds all others.
        local scanRadius=allowance+THREAT_MARGIN
        local threat = api('scan_entities', {category='npc',npcFilter='hostile_creature',radius=scanRadius,maxResults=1})
        if not same(threat) then return finish('entity_observation_unavailable') end
        local nearest=nil
        if threat.data.matchedCount > 0 then
            local first=threat.data.items[1]
            if not first or type(first.distancePixels) ~= 'number' or first.distancePixels < 0
                or first.distancePixels > scanRadius then return finish('entity_observation_unavailable') end
            nearest=first.distancePixels
        end
        report.lastThreatCheck={phase='pre_move_snapshot',radiusPixels=scanRadius,
            marginPixels=THREAT_MARGIN,requestedStepPixels=allowance,
            nearestDistancePixels=nearest or json.null,gameUpdate=threat.gameUpdate,
            observedAtUnixMs=threat.observedAtUnixMs}
        if nearest then allowance=min(allowance,nearest-THREAT_MARGIN) end
        report.lastThreatCheck.permittedStepPixels=max(0,allowance)
        if allowance < 32 then return finish('nearby_hostile') end
        if treeType then
            local b = view.data.bounds
            local found = api('scan_tiles', {minX=max(0,b.minX),minY=max(0,b.minY),maxX=b.maxX,maxY=b.maxY,
                tileTypes={treeType},maxResults=4})
            if not same(found) then return finish('tile_observation_unavailable') end
            for _, item in ipairs(found.data.items) do
                local key=tostring(item.x)..':'..tostring(item.y)
                if not landmarkKeys[key] and #landmarks < 32 then
                    landmarkKeys[key]=true
                    landmarks[#landmarks+1]={x=item.x,y=item.y,typeId=item.typeId,
                        contentKey=item.contentKey,gameUpdate=found.gameUpdate,observedAtUnixMs=found.observedAtUnixMs}
                end
            end
            report.lastTileCoverage={bounds=found.data.bounds,complete=found.data.complete,
                unknownCount=found.data.unknownCount,truncated=found.data.truncated,matchedCount=found.data.matchedCount,
                countUnit='tile cells, not trees'}
        end
        local target, rejected = nil, nil
        local candidates=json.array()
        for attempt=1,2 do
            for offset=0,2 do
                local distance=allowance-offset*32
                if distance >= 32 then
                    target,rejected=candidate(direction,distance)
                    candidates[#candidates+1]={direction=direction,distancePixels=distance,
                        targetX=target or json.null,reason=rejected}
                    if target then break end
                end
            end
            if target or asked ~= 'auto' or attempt == 2 then break end
            if report.reversals >= 2 then return finish('reversal_limit') end
            direction=-direction; report.reversals=report.reversals+1
        end
        report.decisions[#report.decisions+1]={step=step,direction=direction,targetX=target or json.null,
            basis=target and 'observed_bounded_2d_candidate_native_plan_required' or rejected,candidates=candidates}
        if not target then return finish(rejected == 'revisit_limit' and rejected or 'no_safe_direction') end
        local beforeX, beforeY, beforeLife = player.position.x, player.position.y, player.life
        log('explore step='..tostring(step)..' direction='..tostring(direction)..' targetX='..tostring(target))
        local action=api('navigate_to_x',{targetX=target})
        if not action.valid or not action.completed or action.endEvidenceStatus ~= 'known' then
            report.actionStatus=action.status; report.actionReason=action.reason
            return finish('action_'..tostring(action.status))
        end
        p=readPlayer()
        if not p or not same(p) then return finish('player_observation_unavailable') end
        local afterX=p.player.position.x
        local moved=abs(afterX-beforeX)
        local oldMin, oldMax=report.visited.minX, report.visited.maxX
        report.visited.minX=min(oldMin,afterX);report.visited.maxX=max(oldMax,afterX)
        local novel=(oldMin-report.visited.minX)+(report.visited.maxX-oldMax)
        report.noNovelSteps=novel < 16 and report.noNovelSteps+1 or 0
        report.distancePixels=report.distancePixels+moved
        report.finish={x=afterX,y=p.player.position.y}
        for bucket=math.floor(min(beforeX,afterX)/64),math.floor(max(beforeX,afterX)/64) do
            visits[bucket]=(visits[bucket] or 0)+1
        end
        report.steps[#report.steps+1]={step=step,direction=direction,targetX=target,fromX=beforeX,toX=afterX,fromY=beforeY,toY=p.player.position.y,
            movedPixels=moved,newHorizontalPixels=novel,gameUpdate=p.gameUpdate}
        log('explore progress='..tostring(moved)..' novel='..tostring(novel))
        if p.player.life < beforeLife or p.player.dead then return finish('health_decreased') end
        if direction*(afterX-beforeX) < 24 then return finish('no_progress') end
        if report.noNovelSteps >= 3 then return finish('no_new_ground') end
        view=api('observe_terrain',{})
        if not same(view) or not view.data or not view.data.terrain then return finish('observation_unavailable') end
    end
    return finish('step_limit')
end
