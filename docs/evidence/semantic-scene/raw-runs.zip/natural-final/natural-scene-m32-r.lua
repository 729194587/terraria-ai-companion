
local view=api('observe_scene',{})
local s=view.data
local choice=nil
if s.actor.navigationProfileSupported then
  for _,c in ipairs(s.landingRegions.items) do
    local ahead=1==1 and c.target.minPlayerLeftX>s.actor.boundsWorldPixels.x+32 or
      1==-1 and c.target.maxPlayerLeftX<s.actor.boundsWorldPixels.x-32
    if ahead and math.abs(c.feetDeltaY)>0.5 and math.abs(c.feetDeltaY)<=64 then choice=c;break end
  end
end
if not choice then return {scene=view,stop='no_observed_directional_region_at_different_height'} end
local action=api('navigate_to_landing_region',choice.target)
if not action.valid or not action.completed then return {scene=view,choice=choice,action=action,stop=action.reason} end
return {scene=view,choice=choice,action=action,after=api('observe_scene',{}),stop='one_action_budget'}
