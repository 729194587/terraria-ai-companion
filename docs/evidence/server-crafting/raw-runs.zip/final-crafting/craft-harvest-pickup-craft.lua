
local before=api('inspect_inventory',{mode='full'})
api('select_hotbar_slot',{slot=2})
local tree=api('inspect_tile',{x=2098,y=218});assert(tree.data.cell.hasTile)
local mined=api('mine_tile',{x=2098,y=218});assert(mined.completed)
local p=api('get_player_state',{})
local moved=api('navigate_to_x',{targetX=2098*16});assert(moved.completed)
api('wait',{milliseconds=700})
local bag=api('inspect_inventory',{mode='full'})
local found=api('resolve_content',{kind='item',query='Terraria/WorkBench'})
local q=api('query_recipes',{resultType=found.data.candidates[1].typeId})
assert(#q.data.items>0)
local r=q.data.items[1]
local made=api('craft_recipe',{recipeId=r.recipeId,recipeToken=r.recipeToken,crafts=1})
assert(made.completed and made.evidence.inventoryVerified)
return {before=before,mined=mined,moved=moved,afterHarvest=bag,recipe=r,made=made,after=api('inspect_inventory',{mode='full'})}
