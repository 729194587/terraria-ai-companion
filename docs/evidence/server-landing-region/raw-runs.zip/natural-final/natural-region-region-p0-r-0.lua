
local before=api('observe_terrain',{})
local p=api('get_player_state',{})
local candidates={{minPlayerLeftX=33728,maxPlayerLeftX=33732,surfaceY=3760},{minPlayerLeftX=33776,maxPlayerLeftX=33812,surfaceY=3776}}
table.sort(candidates,function(a,b)
  return math.abs(a.minPlayerLeftX-p.player.position.x)<math.abs(b.minPlayerLeftX-p.player.position.x)
end)
assert(#candidates>0)
local goal=candidates[1]
local action=api('navigate_to_landing_region',goal)
return {before=before,goal=goal,action=action,after=api('get_player_state',{})}
