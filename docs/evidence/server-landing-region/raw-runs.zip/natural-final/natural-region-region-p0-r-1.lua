
local before=api('observe_terrain',{})
local p=api('get_player_state',{})
local candidates={{minPlayerLeftX=33824,maxPlayerLeftX=33860,surfaceY=3776},{minPlayerLeftX=33904,maxPlayerLeftX=33908,surfaceY=3792}}
table.sort(candidates,function(a,b)
  return math.abs(a.minPlayerLeftX-p.player.position.x)<math.abs(b.minPlayerLeftX-p.player.position.x)
end)
assert(#candidates>0)
local goal=candidates[1]
local action=api('navigate_to_landing_region',goal)
return {before=before,goal=goal,action=action,after=api('get_player_state',{})}
