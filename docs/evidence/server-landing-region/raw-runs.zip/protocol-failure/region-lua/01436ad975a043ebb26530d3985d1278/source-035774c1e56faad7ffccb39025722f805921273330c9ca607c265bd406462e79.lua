
local before=api('observe_terrain',{})
local p=api('get_player_state',{})
local candidates={{minPlayerLeftX=33712,maxPlayerLeftX=33716,surfaceY=3504},{minPlayerLeftX=33728,maxPlayerLeftX=33732,surfaceY=3504},{minPlayerLeftX=33744,maxPlayerLeftX=33748,surfaceY=3504},{minPlayerLeftX=33760,maxPlayerLeftX=33764,surfaceY=3504},{minPlayerLeftX=33776,maxPlayerLeftX=33780,surfaceY=3504}}
table.sort(candidates,function(a,b)
  return math.abs(a.minPlayerLeftX-p.player.position.x)<math.abs(b.minPlayerLeftX-p.player.position.x)
end)
assert(#candidates>0)
local goal=candidates[1]
local action=api('navigate_to_landing_region',goal)
return {before=before,goal=goal,action=action,after=api('get_player_state',{})}
