
local p=api('get_player_state',{})
local terrain=api('observe_terrain',{})
local bag=api('inspect_inventory',{mode='hotbar'})
local materials={}
for _,i in ipairs(bag.data.inventory) do
  if not i.empty and i.stack>0 and i.use.createTile>=0 then materials[#materials+1]=i end
end
assert(#materials>0)
table.sort(materials,function(a,b) return a.hotbarKey<b.hotbarKey end)
local material=materials[1]
local candidates={{x=2109+1,y=217},{x=2109,y=217}}
local target=nil
for _,c in ipairs(candidates) do
  local tile=api('inspect_tile',c)
  if tile.valid and tile.data.cell.knowledge=='read' and not tile.data.cell.hasTile then target=c; break end
end
assert(target)
local selected=api('select_hotbar_slot',{slot=material.hotbarKey})
assert(selected.valid and selected.completed)
local action=api('place_tile',target)
assert(action.valid and action.completed and action.evidence.consumedCount==1)
local after=api('inspect_tile',target)
local inventory=api('inspect_inventory',{mode='selected'})
assert(after.data.cell.hasTile and after.data.cell.tileType==material.use.createTile)
assert(inventory.data.inventory[1].stack==material.stack-1)
return {before=p,terrain=terrain,material=material,target=target,action=action,after=after,inventory=inventory}
