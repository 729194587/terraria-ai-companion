from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs/evidence/vertical-navigation'
OUT.mkdir(parents=True,exist_ok=True)
RUNS={
 'baseline':'.local/companion-g82-native-ee6d03bb760f4419bd2322465a18eaac',
 'intermediate-vertical':'.local/companion-g82-native-21c25100465647299e97335371844d33',
 'intermediate-landing':'.local/companion-g82-native-032fe8c494f844398a86cb83c85d89b0',
 'input-tick-failure':'.local/companion-g82-native-03c24579da72412c9a21a0933ba96054',
 'final':'.local/companion-g82-native-648eac42477c4a6f91aad8d6a1f38598',
}
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def actions(r):
    value=r.get('value')
    return [x['action'] for x in value] if isinstance(value,list) else [r.get('lastAction') or {}]

final=ROOT/RUNS['final']
assert read(final/'result.json')['result']=='passed'
summary={'baseCommit':'2c70ec8b278e210b651c06b8803cb4bbb6d970c5','packageVersion':'0.1.63',
    'nativeScenarios':[],'offlineScenarios':[]}
counts={'completed':0,'failed':0}
for filename in ('terrain-result.json','vertical-result.json'):
    matrix=read(final/filename)
    assert matrix['passed']
    for row in matrix['scenarios']:
        assert row['passed']
        aa=actions(row['result'])
        trace=row['motion']
        goals=row.get('goals') or [a['targetRegion'] for a in aa]
        expected=row.get('expected',row.get('expectedPass'))
        assert len(aa)==len(goals) if expected else len(aa)==1
        entries=[]
        for a,goal in zip(aa,goals):
            e=a['evidence'];end=a['endEvidence'];nav=e['navigation']
            assert a['valid'] and a['targetRegion']==goal
            assert a['endEvidenceStatus']=='known' and end['inputsReleased']
            assert end['worldSessionId']==row['fixture']['world']
            assert end['actorGeneration']==row['fixture']['generation'] and end['actorSlot']==row['fixture']['slot']
            assert e['settled'] and e['grounded'] and e['safeSupport']
            if expected:
                assert a['completed'] and a['status']=='completed' and e['arrived']
                assert goal['minPlayerLeftX']<=e['x']<=goal['maxPlayerLeftX']
                assert abs(e['y']+42-goal['surfaceY'])<=.5
                assert abs(e['velocityBeforeRelease']['X'])<=.1 and abs(e['velocityBeforeRelease']['Y'])<=.1
            else:
                assert a['status']=='failed' and not a['completed'] and not e['arrived']
            counts[a['status']]+=1
            entries.append({'goal':goal,'status':a['status'],'reason':a.get('reasonDetail'),
                'actual':{k:e[k] for k in ('x','y','vx','vy','grounded','safeSupport','settled','updates')},
                'finalPlan':{k:nav[k] for k in ('PlanNumber','ReachedGoal','TimeBudgetReached','Expansions','PlanMilliseconds','PlannedActions','CompletedActions','CompletedJumps')},
                'endEvidenceStatus':a['endEvidenceStatus'],'inputsReleased':end['inputsReleased']})
        if row['scene']=='shaft_up':
            inputs=[f['injectedInput'] for f in trace if f.get('injectedInput') is not None]
            assert inputs and any(i['jump'] for i in inputs) and all(not i['left'] and not i['right'] for i in inputs)
            assert max(f.get('maxError') or 0 for f in trace)<=.01
        summary['nativeScenarios'].append({'matrix':filename,'scene':row['scene'],'direction':row['direction'],
            'expected':expected,'actions':entries,'traceFrames':len(trace),
            'observedPlans':list({(f.get('PlanNumber'),f.get('PlanMilliseconds')):
                {k:f.get(k) for k in ('PlanNumber','ReachedGoal','TimeBudgetReached','Expansions','PlanMilliseconds')}
                for f in trace if f.get('PlanNumber')}.values()),
            'maxError':max((f.get('maxError') or 0 for f in trace),default=0),
            'evidence':f"raw-runs.zip!final/{filename}"})
for line in (ROOT/'.local/vertical-fixed-matrix.log').read_text(encoding='utf-8-sig').splitlines():
    if line.startswith('{'):
        row=json.loads(line);assert row['arrived']==row['expected']
        summary['offlineScenarios'].append({'scene':row['name'],'expected':row['expected'],**row['rows'][-1]})
summary['nativeCounts']={'scenarios':len(summary['nativeScenarios']),'actions':sum(counts.values()),**counts}
assert summary['nativeCounts']==dict(scenarios=38,actions=44,completed=34,failed=10)
baseline=[]
for p in (ROOT/RUNS['baseline']/'vertical-lua').rglob('events.jsonl'):
    for i,line in enumerate(p.read_text(encoding='utf-8-sig').splitlines(),1):
        e=json.loads(line)
        if e.get('type')=='lua_api_result' and 'no safe landing/progress (18 candidates)' in str(e.get('action',{})):
            a=e['action'];n=a['evidence']['navigation']
            assert a['status']=='failed' and n['Expansions']==1 and n['TimeBudgetReached'] is False
            baseline.append({'entry':'baseline/'+p.relative_to(ROOT/RUNS['baseline']).as_posix(),'line':i,'action':a})
assert len(baseline)==1
summary['baselineShaft']=baseline[0]
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
table=['# 最终包逐场原生矩阵','',
 '世界像素，X 为玩家左边缘，Y 为脚底；方向 1=右、-1=左。每个交替高度场景连续执行四动作，中间不重置。',
 '规划栏记录终段局部计划：完整表示已找到可行落脚路线，不承诺最优；原始中间计划见 summary.json 的 observedPlans。失败场景可先执行安全部分路线。',
 '', '| 场景 / 方向 / 段 | 目标 X / 脚底 Y | 规划终段 | 实际 X / 脚底 Y | 终态 | 释放 | 原因 |',
 '| --- | --- | --- | --- | --- | --- | --- |']
for row in summary['nativeScenarios']:
    for i,a in enumerate(row['actions'],1):
        g=a['goal'];p=a['finalPlan'];v=a['actual']
        plan=('完整' if p['ReachedGoal'] else '未达目标')+f"；{p['Expansions']}扩展；"+('时间预算退出' if p['TimeBudgetReached'] else '未耗尽时间预算')
        table.append(f"| {row['scene']} / {row['direction']} / {i} | [{g['minPlayerLeftX']}, {g['maxPlayerLeftX']}] / {g['surfaceY']} | {plan} | {v['x']:.3f} / {v['y']+42:.3f} | {a['status']} | known / released | {a['reason'] or '区域、支撑与自然停稳已核验'} |")
(OUT/'matrix.md').write_text('\n'.join(table)+'\n',encoding='utf-8')
files=[]
with zipfile.ZipFile(OUT/'raw-runs.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    def add(path,name):
        data=path.read_bytes();z.writestr(name,data)
        files.append(dict(path=name,source=str(path),bytes=len(data),sha256=sha(data)))
    for name,profile in RUNS.items():
        base=ROOT/profile
        for p in sorted(base.rglob('*')):
            rel=p.relative_to(base)
            if not p.is_file() or any(x in rel.parts for x in ('previous-installation-logs','Mods','Worlds','Players','VirtualPlayerEngineProbe')):continue
            if p.suffix in ('.json','.jsonl','.lua','.log'):add(p,name+'/'+rel.as_posix())
    for p in sorted((ROOT/'.local').glob('vertical-*.log')):add(p,'checks/'+p.name)
    add(ROOT/'.local/verify-vertical-package.ps1','checks/verify-vertical-package.ps1')
    for name in ('baseline','fixed','final','confirmed'):
        add(ROOT/f'.local/vertical-{name}-build/Mods/CompanionBridge.tmod',f'packages/{name}.tmod')
    add(ROOT/'tests/native_vertical_navigation.py','source/native_vertical_navigation.py')
    add(ROOT/'tests/VerticalNavigationTests.cs','source/VerticalNavigationTests.cs')
    for rel in ('CompanionBridge/Motion/PhysicsSimulator.cs','CompanionBridge/Motion/StateSpacePlanner.cs',
                'CompanionBridge/Motion/NavigationTask.cs','CompanionBridge/Motion/GameNavigation.cs',
                'CompanionBridge/Motion/NativeMotionWorld.cs','CompanionBridge/ServerIpc/ServerAiNavigation.cs',
                'CompanionBridge/ServerIpc/ServerAiTerrainFixture.cs','CompanionBridge/build.txt',
                'tests/verify_server_ai_native.ps1'):
        add(ROOT/rel,'source/'+rel)
    for suffix in ('.wld','.twld'):
        p=ROOT/('.local/virtual-player-control-host/Worlds/test'+suffix)
        if p.is_file():add(p,'world/source'+suffix)
    add(Path(__file__),'checks/archive-vertical.py')
with zipfile.ZipFile(OUT/'raw-runs.zip') as z:
    for f in files:
        assert sha(z.read(f['path']))==f['sha256']==sha(Path(f['source']).read_bytes())
packages={name:sha((ROOT/f'.local/vertical-{name}-build/Mods/CompanionBridge.tmod').read_bytes()) for name in ('baseline','fixed','final','confirmed')}
manifest={'baseCommit':summary['baseCommit'],'packageVersion':'0.1.63','packageSHA256':packages,
 'engineDLLSHA256':sha(Path('D:/steam/steamapps/common/tModLoader/tModLoader.dll').read_bytes()),
 'runs':[dict(name=n,profile=p,packageSHA256=packages['baseline' if n=='baseline' else 'confirmed' if n=='final' else 'final' if n=='input-tick-failure' else 'fixed']) for n,p in RUNS.items()],
 'summary':{'path':'summary.json','sha256':sha((OUT/'summary.json').read_bytes())},
 'matrix':{'path':'matrix.md','sha256':sha((OUT/'matrix.md').read_bytes())},
 'archive':{'path':'raw-runs.zip','bytes':(OUT/'raw-runs.zip').stat().st_size,'sha256':sha((OUT/'raw-runs.zip').read_bytes())},
 'files':files}
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(counts=summary['nativeCounts'],offlineGoals=len(summary['offlineScenarios']),files=len(files),archive=manifest['archive'],packages=packages)))
