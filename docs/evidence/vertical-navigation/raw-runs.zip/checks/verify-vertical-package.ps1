$ErrorActionPreference='Stop'
$cecil='D:/steam/steamapps/common/tModLoader/Libraries/mono.cecil/0.11.6/lib/netstandard2.0/Mono.Cecil.dll'
Add-Type -Path $cecil
$references=@(Get-ChildItem (Join-Path $PSHOME 'ref') -Filter '*.dll' | Select-Object -ExpandProperty FullName)+@($cecil)
Add-Type -Path tests/ServerAiPackageTests.cs -ReferencedAssemblies $references
[ServerAiPackageTests]::Run((Resolve-Path .local/vertical-confirmed-build/Mods/CompanionBridge.tmod).Path)
