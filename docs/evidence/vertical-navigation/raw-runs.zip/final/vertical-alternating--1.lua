local goals={{minPlayerLeftX=33440,maxPlayerLeftX=33516,surfaceY=3440},{minPlayerLeftX=33312,maxPlayerLeftX=33388,surfaceY=3472},{minPlayerLeftX=33440,maxPlayerLeftX=33516,surfaceY=3440},{minPlayerLeftX=33584,maxPlayerLeftX=33644,surfaceY=3504}}; local results={}

for _,goal in ipairs(goals) do
  local before=api('observe_terrain',{})
  local action=api('navigate_to_landing_region',goal)
  table.insert(results,{goal=goal,before=before,action=action,after=api('get_player_state',{})})
  if not action.completed then break end
end
return results
