local goals={{minPlayerLeftX=33604,maxPlayerLeftX=33608,surfaceY=3440}}; local results={}

for _,goal in ipairs(goals) do
  local before=api('observe_terrain',{})
  local action=api('navigate_to_landing_region',goal)
  table.insert(results,{goal=goal,before=before,action=action,after=api('get_player_state',{})})
  if not action.completed then break end
end
return results
